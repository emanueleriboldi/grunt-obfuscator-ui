import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

import java.awt.GridBagLayout;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

import java.awt.GridBagConstraints;
import javax.swing.JButton;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DnDConstants;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetDropEvent;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JProgressBar;
import javax.swing.JTextArea;
import javax.swing.JFileChooser;
import java.io.OutputStream;
import javax.swing.JScrollPane;

public class MainFrame extends JFrame {

	private JPanel contentPane;
	private JTextField input_txt;
	private JTextField output_txt;
	private JTextArea log = new JTextArea();
	private JProgressBar progressBar;
	private String config = "{\r\n"
			+ "  \"Settings\": {\r\n"
			+ "    \"Input\": \"takeout.jar\",\r\n"
			+ "    \"Output\": \"takeout_out.jar\",\r\n"
			+ "    \"Libraries\": [],\r\n"
			+ "    \"Exclusions\": [],\r\n"
			+ "    \"GenerateRemap\": true,\r\n"
			+ "    \"RemapOutput\": \"mappings.json\",\r\n"
			+ "    \"ParallelProcessing\": false,\r\n"
			+ "    \"CustomDictionary\": [],\r\n"
			+ "    \"DictionaryStartIndex\": 0,\r\n"
			+ "    \"CorruptOutput\": false,\r\n"
			+ "    \"FileRemovePrefix\": [],\r\n"
			+ "    \"FileRemoveSuffix\": []\r\n"
			+ "  },\r\n"
			+ "  \"AntiDebug\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"SourceDebug\": true,\r\n"
			+ "    \"LineDebug\": true,\r\n"
			+ "    \"RenameSourceDebug\": false,\r\n"
			+ "    \"SourceNames\": [\r\n"
			+ "      \"114514.java\",\r\n"
			+ "      \"1919810.kt\",\r\n"
			+ "      \"69420.java\",\r\n"
			+ "      \"你妈死了.kt\"\r\n"
			+ "    ]\r\n"
			+ "  },\r\n"
			+ "  \"Shrinking\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"RemoveInnerClass\": true,\r\n"
			+ "    \"RemoveUnusedLabel\": true,\r\n"
			+ "    \"RemoveNOP\": false,\r\n"
			+ "    \"Exclusions\": []\r\n"
			+ "  },\r\n"
			+ "  \"KotlinOptimizer\": {\r\n"
			+ "    \"Enabled\": false,\r\n"
			+ "    \"RemoveMetadata\": true,\r\n"
			+ "    \"RemoveIntrinsics\": true,\r\n"
			+ "    \"IntrinsicsRemoval\": [\r\n"
			+ "      \"checkExpressionValueIsNotNull\",\r\n"
			+ "      \"checkNotNullExpressionValue\",\r\n"
			+ "      \"checkReturnedValueIsNotNull\",\r\n"
			+ "      \"checkFieldIsNotNull\",\r\n"
			+ "      \"checkParameterIsNotNull\",\r\n"
			+ "      \"checkNotNullParameter\"\r\n"
			+ "    ],\r\n"
			+ "    \"IntrinsicsExclusions\": [],\r\n"
			+ "    \"MetadataExclusions\": []\r\n"
			+ "  },\r\n"
			+ "  \"StringEncrypt\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Intensity\": 1,\r\n"
			+ "    \"Exclusions\": []\r\n"
			+ "  },\r\n"
			+ "  \"NumberEncrypt\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"FloatingPoint\": true,\r\n"
			+ "    \"Intensity\": 1,\r\n"
			+ "    \"Exclusions\": []\r\n"
			+ "  },\r\n"
			+ "  \"ScrambleTransformer\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Intensity\": 1,\r\n"
			+ "    \"RandomName\": false,\r\n"
			+ "    \"RedirectGetStatic\": true,\r\n"
			+ "    \"RedirectSetStatic\": true,\r\n"
			+ "    \"RedirectGetValue\": true,\r\n"
			+ "    \"RedirectSetField\": true,\r\n"
			+ "    \"GenerateOuterClass\": false,\r\n"
			+ "    \"ExcludedClasses\": [],\r\n"
			+ "    \"ExcludedFieldName\": [],\r\n"
			+ "    \"NativeDownCalls\": true,\r\n"
			+ "    \"NativeUpCalls\": false\r\n"
			+ "  },\r\n"
			+ "  \"NativeCandidate\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"NativeAnnotation\": \"Lnet/spartanb312/example/Native;\",\r\n"
			+ "    \"UpCallLimit\": 0,\r\n"
			+ "    \"Exclusions\": []\r\n"
			+ "  },\r\n"
			+ "  \"LocalVariableRename\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Dictionary\": \"Alphabet\",\r\n"
			+ "    \"ThisReference\": false\r\n"
			+ "  },\r\n"
			+ "  \"MethodRename\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Dictionary\": \"Alphabet\",\r\n"
			+ "    \"HeavyOverloads\": false,\r\n"
			+ "    \"RandomKeywordPrefix\": false,\r\n"
			+ "    \"Prefix\": \"\",\r\n"
			+ "    \"Exclusion\": [],\r\n"
			+ "    \"ExcludedName\": []\r\n"
			+ "  },\r\n"
			+ "  \"FieldRename\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Dictionary\": \"Alphabet\",\r\n"
			+ "    \"RandomKeywordPrefix\": false,\r\n"
			+ "    \"Prefix\": \"\",\r\n"
			+ "    \"Exclusion\": [],\r\n"
			+ "    \"ExcludedName\": []\r\n"
			+ "  },\r\n"
			+ "  \"ClassRename\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Dictionary\": \"Alphabet\",\r\n"
			+ "    \"Parent\": \"net/spartanb312/obf/\",\r\n"
			+ "    \"Prefix\": \"\",\r\n"
			+ "    \"CorruptedName\": false,\r\n"
			+ "    \"CorruptedNameExclusions\": [],\r\n"
			+ "    \"ManifestReplace\": [\r\n"
			+ "      \"Main-Class\"\r\n"
			+ "    ],\r\n"
			+ "    \"PluginMainReplace\": false,\r\n"
			+ "    \"BungeeMainReplace\": false,\r\n"
			+ "    \"Exclusion\": [],\r\n"
			+ "    \"MixinSupport\": false,\r\n"
			+ "    \"MixinDictionary\": \"Alphabet\",\r\n"
			+ "    \"MixinPackage\": \"net/spartanb312/client/mixins/\",\r\n"
			+ "    \"TargetMixinPackage\": \"net/spartanb312/obf/mixins/\",\r\n"
			+ "    \"MixinFile\": \"mixins.example.json\",\r\n"
			+ "    \"RefmapFile\": \"mixins.example.refmap.json\"\r\n"
			+ "  },\r\n"
			+ "  \"ShuffleMembers\": {\r\n"
			+ "    \"Enabled\": true,\r\n"
			+ "    \"Methods\": true,\r\n"
			+ "    \"Fields\": true,\r\n"
			+ "    \"Annotations\": true\r\n"
			+ "  },\r\n"
			+ "  \"Watermark\": {\r\n"
			+ "    \"Enabled\": false,\r\n"
			+ "    \"Watermark Message\": \"PROTECTED BY GRUNT KLASS MASTER\"\r\n"
			+ "  }\r\n"
			+ "}\r\n"
			+ "";
	
	public void init() throws IOException {
		if(!new File(System.getProperty("java.io.tmpdir")+"bin_ob.jar").exists())
		{
			JOptionPane.showMessageDialog(null,"Now the software will download some files. The size is around 3MB.\nPlease, don't do anything until this window closes.","Initialization",JOptionPane.INFORMATION_MESSAGE);

			final JProgressBar jProgressBar = new JProgressBar();
	        jProgressBar.setMaximum(100000);
	        JFrame frame = new JFrame("Initialization");
	        frame.setContentPane(jProgressBar);
	        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
	        // Get the screen size.
	        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

	        // Calculate the frame's top-left corner.
	        int x = (screenSize.width - frame.getWidth()) / 2;
	        int y = (screenSize.height - frame.getHeight()) / 2;

	        // Set the frame's location.
	        frame.setLocation(x, y);
	        frame.setSize(300, 70);
	        frame.setVisible(true);
	        
	        Runnable updatethread = new Runnable() {
	            public void run() {
	                try {

	                    URL url = new URL("https://github.com/SpartanB312/Grunt/releases/download/1.5.7-stable/grunt-1.5.7.jar");
	                    HttpURLConnection httpConnection = (HttpURLConnection) (url.openConnection());
	                    long completeFileSize = httpConnection.getContentLength();
	                    
	                    String tempDirPath = System.getProperty("java.io.tmpdir");
	                    
	                    java.io.BufferedInputStream in = new java.io.BufferedInputStream(httpConnection.getInputStream());
	                    java.io.FileOutputStream fos = new java.io.FileOutputStream(
	                    		tempDirPath+"bin_ob.jar");
	                    java.io.BufferedOutputStream bout = new BufferedOutputStream(
	                            fos, 1024);
	                    byte[] data = new byte[1024];
	                    long downloadedFileSize = 0;
	                    int x = 0;
	                    while ((x = in.read(data, 0, 1024)) >= 0) {
	                        downloadedFileSize += x;

	                        // calculate progress
	                        final int currentProgress = (int) ((((double)downloadedFileSize) / ((double)completeFileSize)) * 100000d);

	                        // update progress bar
	                        SwingUtilities.invokeLater(new Runnable() {

	                            @Override
	                            public void run() {
	                                jProgressBar.setValue(currentProgress);
	                            }
	                        });

	                        bout.write(data, 0, x);
	                    }
	                    bout.close();
	                    in.close();
	                    
	                    frame.setVisible(false);
	                } catch (FileNotFoundException e) {
	        			JOptionPane.showMessageDialog(null,"Unable to init the software.\nDetails: "+e.toString(),"Error during init",JOptionPane.ERROR_MESSAGE);
	        			System.exit(ERROR);
	                } catch (IOException e) {
	        			JOptionPane.showMessageDialog(null,"Unable to init the software.\nDetails: "+e.toString(),"Error during init",JOptionPane.ERROR_MESSAGE);
	        			System.exit(ERROR);
	                }
	            }
	        };
	        new Thread(updatethread).

	        start();
		}
    }
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainFrame frame = new MainFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void browse_input_file() { 
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
		    "Java File", "jar");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(getParent());
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			input_txt.setText(chooser.getSelectedFile().getPath());
		}
	}
	
	public void browse_output_file() { 
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
		    "Java File", "jar");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showSaveDialog(getParent());
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			output_txt.setText(chooser.getSelectedFile().getPath());
		}
	}
	
	public String inputToString(InputStream origin) throws IOException
	{
		StringBuilder sb = new StringBuilder();
		for (int ch; (ch = origin.read()) != -1; ) {
		    sb.append((char) ch);
		}
		return sb.toString();
	}
	
	public void start()
	{
		log.setText(null);
		File f = new File(input_txt.getText());
		if(!f.exists() || f.isDirectory()) {
			Toolkit.getDefaultToolkit().beep();
			log.append("Input file not valid. Please check.");
			progressBar.setValue(100);
			progressBar.setForeground(Color.RED);
			return;
		}
		
		if(!input_txt.getText().contains(".jar"))
		{
			Toolkit.getDefaultToolkit().beep();
			log.append("Input file extension not valid / Not supported Java extension. Please check.");
			progressBar.setValue(100);
			progressBar.setForeground(Color.RED);
			return;
		}
		
		try {
			log.append("Setting up configs...\n");

		    FileWriter myWriter = new FileWriter(System.getProperty("java.io.tmpdir")+"bin_ob_config.bin");
		    
		    String config_model = config;
		    
		    config_model = config_model.replace("takeout.jar", input_txt.getText().replace("\\", "\\\\"));
		    config_model = config_model.replace("takeout_out.jar", output_txt.getText().replace("\\", "\\\\"));

		    myWriter.write(config_model);
		    myWriter.close();
		    
			log.append("Starting...\n");

			Process proc = Runtime.getRuntime().exec("java -jar "+ System.getProperty("java.io.tmpdir")+"bin_ob.jar" +" "+ System.getProperty("java.io.tmpdir")+"bin_ob_config.bin");
			InputStream in = proc.getInputStream();
			InputStream err = proc.getErrorStream();
			
			String in_s = inputToString(in);
	        // Find the index of the substring "Initializing Grunt".
	        int index = in_s.indexOf("bin_ob_config.bin");

	        // If the substring is found, delete all characters before the substring.
	        if (index != -1) {
	        	in_s = in_s.substring(index);
	        }
	        
			Toolkit.getDefaultToolkit().beep();

			log.append(in_s.replace("bin_ob_config.bin", ""));
			progressBar.setForeground(Color.GREEN);

			if(inputToString(err).length() > 5)
			{
				log.append("\nWhile executing, these errors occured: \n"+inputToString(err));
				progressBar.setForeground(Color.RED);
			}
			
			progressBar.setValue(100);
			new File(System.getProperty("java.io.tmpdir")+"bin_ob_config.bin").delete();
			
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,"Unable to prooced.\nDetails: "+e.toString(),"Error during obfuscation",JOptionPane.ERROR_MESSAGE);
			return;
		}

	}
	
	  
	/**
	 * Create the frame.
	 */
	public MainFrame() {
		setTitle("Grunt UI");	
        // Get the screen size.
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();

        // Calculate the frame's top-left corner.
        int x = (screenSize.width - getWidth()) / 2;
        int y = (screenSize.height - getHeight()) / 2;

        // Set the frame's location.
        setLocation(x, y);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{0, 0, 0, 0};
		gbl_contentPane.rowHeights = new int[]{0, 0, 0, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 1.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, 1.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JLabel lblNewLabel = new JLabel("Input File");
		GridBagConstraints gbc_lblNewLabel = new GridBagConstraints();
		gbc_lblNewLabel.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel.gridx = 0;
		gbc_lblNewLabel.gridy = 0;
		contentPane.add(lblNewLabel, gbc_lblNewLabel);
		
		input_txt = new JTextField();
		
		GridBagConstraints gbc_input_txt = new GridBagConstraints();
		gbc_input_txt.insets = new Insets(0, 0, 5, 5);
		gbc_input_txt.fill = GridBagConstraints.HORIZONTAL;
		gbc_input_txt.gridx = 1;
		gbc_input_txt.gridy = 0;
		contentPane.add(input_txt, gbc_input_txt);
		input_txt.setColumns(10);
		
		JButton input_btn = new JButton("Browse");
		GridBagConstraints gbc_input_btn = new GridBagConstraints();
		gbc_input_btn.insets = new Insets(0, 0, 5, 0);
		gbc_input_btn.gridx = 2;
		gbc_input_btn.gridy = 0;
		contentPane.add(input_btn, gbc_input_btn);
		
		JLabel lblNewLabel_1 = new JLabel("Output File");
		GridBagConstraints gbc_lblNewLabel_1 = new GridBagConstraints();
		gbc_lblNewLabel_1.anchor = GridBagConstraints.EAST;
		gbc_lblNewLabel_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblNewLabel_1.gridx = 0;
		gbc_lblNewLabel_1.gridy = 1;
		contentPane.add(lblNewLabel_1, gbc_lblNewLabel_1);
		
		output_txt = new JTextField();
		GridBagConstraints gbc_output_txt = new GridBagConstraints();
		gbc_output_txt.insets = new Insets(0, 0, 5, 5);
		gbc_output_txt.fill = GridBagConstraints.HORIZONTAL;
		gbc_output_txt.gridx = 1;
		gbc_output_txt.gridy = 1;
		contentPane.add(output_txt, gbc_output_txt);
		output_txt.setColumns(10);
		
		JButton output_btn = new JButton("Browse");
		GridBagConstraints gbc_output_btn = new GridBagConstraints();
		gbc_output_btn.insets = new Insets(0, 0, 5, 0);
		gbc_output_btn.gridx = 2;
		gbc_output_btn.gridy = 1;
		contentPane.add(output_btn, gbc_output_btn);
		
		JButton start_btn = new JButton("Start");
		GridBagConstraints gbc_start_btn = new GridBagConstraints();
		gbc_start_btn.fill = GridBagConstraints.HORIZONTAL;
		gbc_start_btn.insets = new Insets(0, 0, 5, 5);
		gbc_start_btn.gridx = 1;
		gbc_start_btn.gridy = 2;
		contentPane.add(start_btn, gbc_start_btn);
		
		JScrollPane scrollPane = new JScrollPane();
		GridBagConstraints gbc_scrollPane = new GridBagConstraints();
		gbc_scrollPane.fill = GridBagConstraints.BOTH;
		gbc_scrollPane.gridwidth = 3;
		gbc_scrollPane.insets = new Insets(0, 0, 5, 0);
		gbc_scrollPane.gridx = 0;
		gbc_scrollPane.gridy = 3;
		contentPane.add(scrollPane, gbc_scrollPane);
		scrollPane.setViewportView(log);
		
		log.setEditable(false);
		
		progressBar = new JProgressBar();
		GridBagConstraints gbc_progressBar = new GridBagConstraints();
		gbc_progressBar.gridwidth = 3;
		gbc_progressBar.fill = GridBagConstraints.HORIZONTAL;
		gbc_progressBar.gridx = 0;
		gbc_progressBar.gridy = 4;
		contentPane.add(progressBar, gbc_progressBar);
		

		input_txt.setDropTarget(new DropTarget() {
	        public synchronized void drop(DropTargetDropEvent evt) {
	            try {
	                evt.acceptDrop(DnDConstants.ACTION_COPY);
	                List<File> droppedFiles = (List<File>) evt
	                        .getTransferable().getTransferData(
	                                DataFlavor.javaFileListFlavor);
	                for (File file : droppedFiles) {
	                	input_txt.setText(file.getPath());
	                }
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });
		output_txt.setDropTarget(new DropTarget() {
	        public synchronized void drop(DropTargetDropEvent evt) {
	            try {
	                evt.acceptDrop(DnDConstants.ACTION_COPY);
	                List<File> droppedFiles = (List<File>) evt
	                        .getTransferable().getTransferData(
	                                DataFlavor.javaFileListFlavor);
	                for (File file : droppedFiles) {
	                	output_txt.setText(file.getPath());
	                }
	            } catch (Exception ex) {
	                ex.printStackTrace();
	            }
	        }
	    });

		input_btn.addActionListener(e -> browse_input_file());
		output_btn.addActionListener(e -> browse_output_file());
		start_btn.addActionListener(e -> start());
		try {
			init();
		} catch (IOException e) {
			JOptionPane.showMessageDialog(null,"Unable to prooced.\nDetails: "+e.toString(),"Error during obfuscation",JOptionPane.ERROR_MESSAGE);
		}
	}

}
